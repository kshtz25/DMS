package com.dms.dunkin.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Value;

@Value
public class DMSStoreGroups {
	
	@JsonProperty("storeGroupId")
	private String storeGroupId;
	
	@JsonProperty("type")
	private String type;

}
