package com.dms.dunkin.model;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class DMSNewActivities {
	
	@JsonProperty("addToDefaultActivityMaster")
	private String addToDefaultActivityMaster;
	
	@JsonProperty("activityType")
	private String activityType;
	
	@JsonProperty("activityDetails")
	private String activityDetails;
	
	@JsonProperty("activityPreRequisite")
	private String activityPreRequisite;
	
	@JsonProperty("activityStatus")
	private String activityStatus;
	
	@JsonProperty("activityReference")
	private String activityReference;
	
	@JsonProperty("activityStartDate")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy '-' HH:mm")
	private LocalDateTime activityStartDate;
	
	@JsonProperty("activityEndDate")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy '-' HH:mm")
	private LocalDateTime activityEndDate;
	
}
