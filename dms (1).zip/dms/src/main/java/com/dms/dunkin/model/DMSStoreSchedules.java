package com.dms.dunkin.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.dms.dunkin.commons.util.StringPrefixedSequenceIdGenerator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Entity (name="dms_store_schedules")
@DynamicUpdate
public class DMSStoreSchedules {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "dms_store_schedules_seq")
	@GenericGenerator(
	        name = "dms_store_schedules_seq", 
	        strategy = "com.dms.dunkin.commons.util.StringPrefixedSequenceIdGenerator", 
	        parameters = {
	            @Parameter(name = StringPrefixedSequenceIdGenerator.INCREMENT_PARAM, value = "1"),
	            @Parameter(name = StringPrefixedSequenceIdGenerator.VALUE_PREFIX_PARAMETER, value = "S"),
	            @Parameter(name = StringPrefixedSequenceIdGenerator.NUMBER_FORMAT_PARAMETER, value = "%05d") })
	@Column(name = "schedule_id", nullable = false)
	@JsonProperty("scheduleId")
	private String scheduleId;

	@Column(name = "store_id", nullable = false)
	@JsonProperty("stores")
	private String storeId;

	@Column(name = "software_id", nullable = false)
	@JsonProperty("softwareId")
	private String softwareId;

	@Column(name = "version")
	@JsonProperty("softwareVersion")
	private String version;

	@Column(name = "login_id")
	@JsonProperty("scheduleUserId")
	private String loginId;

	@Column(name = "software_name")
	@JsonProperty("softwareName")
	private String softwareName;

	@Column(name = "createts")
	private LocalDateTime createts;

	@Column(name = "modifyts")
	private LocalDateTime modifyts;

	@Column(name = "schedule_dt")
	private LocalDateTime scheduleDt;

	@Column(name = "status")
	@JsonProperty("scheduleStatus")
	private String status;

	@Column(name = "schedule_start_date")
	@JsonProperty("scheduleStartDt")
	private LocalDateTime scheduleStartDate;

	@Column(name = "schedule_end_date")
	@JsonProperty("scheduleEndDt")
	private LocalDateTime scheduleEndDate;

	@Column(name = "notes")
	@JsonProperty("notes")
	private String notes;

	@Column(name = "createuserid")
	@JsonProperty("createUserId")
	private String createuserid;

	@Column(name = "modifyuserid")
	@JsonProperty("modifyUserId")
	private String modifyuserid;

}
