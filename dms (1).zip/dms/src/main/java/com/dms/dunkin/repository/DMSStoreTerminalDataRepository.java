package com.dms.dunkin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dms.dunkin.model.DMSStoreTerminalData;

@Repository
public interface DMSStoreTerminalDataRepository extends JpaRepository<DMSStoreTerminalData, Long> {
	
//	List<DunkinStoreTerminalData> findByGroupId(String groupId);
	List<DMSStoreTerminalData> findAllByGroupIdAndTerminalType(String storeGroupId, String type);

}
