package com.dms.dunkin.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dms.dunkin.model.DMSScheduleTechnicianAssignmentDetails;

@Repository
public interface DMSScheduleTechnicianAssignmentDetailsRepository extends JpaRepository<DMSScheduleTechnicianAssignmentDetails, String> {
	
}
