package com.dms.dunkin.services;

import java.time.LocalDateTime;
import java.util.List;

import com.dms.dunkin.model.DMSNewActivities;
import com.dms.dunkin.model.DMSStoreGroups;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class DMSStoreSchedulesEvaluateRequest {


	@JsonProperty("scheduleId")
	private String scheduleId;

	@JsonProperty("stores")
	private List<String> storeId;

	@JsonProperty("softwareId")
	private String softwareId;

	@JsonProperty("softwareVersion")
	private String version;

	@JsonProperty("scheduleUserId")
	private String loginId;

	@JsonProperty("softwareName")
	private String softwareName;

	@JsonProperty("createts")
	private String createts;

	@JsonProperty("modifyts")
	private String modifyts;

	@JsonProperty("scheduleDt")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy '-' HH:mm")
	private LocalDateTime scheduleDt;
	
	@JsonProperty("scheduleStatus")
	private String status;
	
	@JsonProperty("scheduleStartDt")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy '-' HH:mm")
	private LocalDateTime scheduleStartDate;
	
	@JsonProperty("scheduleEndDt")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy '-' HH:mm")
	private LocalDateTime scheduleEndDate;
	
	@JsonProperty("notes")
	private String notes;

	@JsonProperty("createUserId")
	private String createuserid;

	@JsonProperty("modifyUserId")
	private String modifyuserid;
	
	@JsonProperty("stdActivityIDs")
	private List<String> stdActivityIDs;
	
	@JsonProperty("storeGroups")
	private List<DMSStoreGroups> storeGroups;
	
	@JsonProperty("technicianIDs")
	private List<String> technicianIDs;
	
	@JsonProperty("newActivities")
	private List<DMSNewActivities> dMSNewActivities;
	
}