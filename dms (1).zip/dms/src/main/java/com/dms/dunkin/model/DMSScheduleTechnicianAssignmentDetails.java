package com.dms.dunkin.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.dms.dunkin.commons.util.StringPrefixedSequenceIdGenerator;

import lombok.Data;

@Data
@Entity(name="dms_schedule_technician_assignment_details")
@DynamicUpdate
public class DMSScheduleTechnicianAssignmentDetails {

    @Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "dms_schedule_technician_seq")
	@GenericGenerator(
	        name = "dms_schedule_technician_seq", 
	        strategy = "com.dms.dunkin.commons.util.StringPrefixedSequenceIdGenerator", 
	        parameters = {
	            @Parameter(name = StringPrefixedSequenceIdGenerator.INCREMENT_PARAM, value = "1"),
	            @Parameter(name = StringPrefixedSequenceIdGenerator.VALUE_PREFIX_PARAMETER, value = "ST"),
	            @Parameter(name = StringPrefixedSequenceIdGenerator.NUMBER_FORMAT_PARAMETER, value = "%05d") })
    @Column(name="schedule_technician_id", unique=true, nullable=false)
    private String schedule_technician_id;
    
    @Column(name="schedule_id", nullable=false)
    private String scheduleId;

    @Column(name="technician_id", nullable=false)
    private String technicianId;
    
    @Column(name="acitivity_id")
    private String acitivityId;
    
    @Column(name="createuserid")
    private String createuserid;
    
    @Column(name="modifyuserid")
    private String modifyuserid;
    
    @Column(name="createts")
    private LocalDateTime createts;
    
    @Column(name="modifyts")
    private LocalDateTime modifyts;

}
