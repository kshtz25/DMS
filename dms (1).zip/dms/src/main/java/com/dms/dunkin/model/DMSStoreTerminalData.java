// Generated with g9.

package com.dms.dunkin.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.annotations.DynamicUpdate;

import lombok.Data;

@Data
@Entity(name = "dms_store_terminal_data")
@DynamicUpdate
public class DMSStoreTerminalData {

	
    @Id
	@Column(name="store_terminal_id", nullable=false)
	private Long store_terminal_id;
    
    @Column(name="store_id", nullable=false)
    private  String storeId;
    
	@Column(name="group_id")
    private String groupId;
    
    @Column(name="terminal_id", nullable=false)
    private String terminalId;
    
    @Column(name="account_id")
    private String accountId;
    
    @Column(name="description")
    private String description;

    @Column(name="hoststatechangedate")
    private LocalDateTime hoststatechangedate;
    
    @Column(name="ishostonline")
    private String ishostonline;
    
    @Column(name="createts")
    private LocalDateTime createts;
    
    @Column(name="modifyts")
    private LocalDateTime modifyts;
        
    @Column(name="terminal_desc")
    private String terminalDesc;
    
    @Column(name="group_name")
    private String groupName;
    
    @Column(name="terminal_type")
    private String terminalType;


}
