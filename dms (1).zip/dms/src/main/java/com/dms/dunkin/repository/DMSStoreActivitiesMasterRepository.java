package com.dms.dunkin.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.dms.dunkin.model.DMSActivitiesMaster;

@Repository
public interface DMSStoreActivitiesMasterRepository extends JpaRepository<DMSActivitiesMaster, String> {
	
	@Query(value = "SELECT nextval('dms_new_activity_seq')", nativeQuery = 
	        true)
	String getNextNewActivitySeqId();

}
