package com.dms.dunkin.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.dms.dunkin.commons.util.StringPrefixedSequenceIdGenerator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Entity (name="dms_store_schedule_activities")
@DynamicUpdate
public class DMSStoreScheduleActivities {

	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "dms_activity_seq")
	@GenericGenerator(
	        name = "dms_activity_seq", 
	        strategy = "com.dms.dunkin.commons.util.StringPrefixedSequenceIdGenerator", 
	        parameters = {
	            @Parameter(name = StringPrefixedSequenceIdGenerator.INCREMENT_PARAM, value = "1"),
	            @Parameter(name = StringPrefixedSequenceIdGenerator.VALUE_PREFIX_PARAMETER, value = "AS"),
	            @Parameter(name = StringPrefixedSequenceIdGenerator.NUMBER_FORMAT_PARAMETER, value = "%05d") })
	@Column(name="activity_schedule_id", nullable=false)
	private String schedule_activity_id;
	
	@Column(name="activity_id", nullable=false)
	@JsonProperty("activityId")
    private String activityId;
	
    @Column(name="start_date")
    @JsonProperty("startDate")
    private LocalDateTime startDate;
    
    @Column(name="end_date")
    @JsonProperty("endDate")
    private LocalDateTime endDate;
    
    @Column(name="status")
    @JsonProperty("status")
    private String status;
    
    @Column(name="createts")
    @JsonProperty("createts")
    private LocalDateTime createts;
    
    @Column(name="modifyts")
    @JsonProperty("modifyts")
    private LocalDateTime modifyts;
	
	@Column(name="schedule_id")
	@JsonProperty("scheduleId")
    private String scheduleId;
    
    @Column(name="login_id")
    @JsonProperty("loginId")
    private String loginId;
    
    @Column(name="activity_details")
    @JsonProperty("activityDetails")
    private String activityDetails;
    
    @Column(name="pre_requisite")
    @JsonProperty("preRequisite")
    private String preRequisite;
    
    @Column(name="reference")
    @JsonProperty("reference")
    private String reference;
    
    @Column(name="createuserid")
    @JsonProperty("createuserid")
    private String createuserid;
    
    @Column(name="modifyuserid")
    @JsonProperty("modifyuserid")
    private String modifyuserid;

}
