package com.dms.dunkin.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dms.dunkin.model.DMSStoreSchedules;
import com.dms.dunkin.services.DMSScheduleManagementService;
import com.dms.dunkin.services.DMSStoreSchedulesEvaluateRequest;

@RestController
@CrossOrigin(origins = "${application.crossorigin}")
public class DMSScheduleManagementController {

	@Autowired
	DMSScheduleManagementService dmsScheduleManagementService;

	@GetMapping("/getAllSchedules")
	public List<DMSStoreSchedules> getAllSchedules() {
		return dmsScheduleManagementService.listAllSchedules();

	}

	@RequestMapping(value="${application.createschedule.api.uri}", method = RequestMethod.POST)
	public ResponseEntity<Map<String, Integer>> createSchedule(@RequestBody DMSStoreSchedulesEvaluateRequest dmsStoreSchedule) {
		return new ResponseEntity<>(dmsScheduleManagementService.saveDMSStoreScheduleData(dmsStoreSchedule), HttpStatus.CREATED);

	}
	
//	@RequestMapping(value="/createScheduleNoAuth", method = RequestMethod.POST)
//	public ResponseEntity<Map<String, Integer>> createScheduleNoAuth(@RequestBody DMSStoreSchedulesEvaluateRequest dmsStoreSchedule) {
//		return new ResponseEntity<>(dmsScheduleManagementService.saveDMSStoreScheduleData(dmsStoreSchedule), HttpStatus.CREATED);
//
//	}

}
