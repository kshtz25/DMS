package com.dms.dunkin.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dms.dunkin.model.DMSStoreScheduleActivities;

@Repository
public interface DMSStoreScheduleActivitiesRepository extends JpaRepository<DMSStoreScheduleActivities, String> {

}
